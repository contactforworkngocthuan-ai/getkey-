-- Run this file in Supabase Dashboard -> SQL Editor.
-- Only hashes are stored: the original license key is never persisted,
-- and the HWID is stored as a SHA-256 hash for device binding.

create extension if not exists pgcrypto;

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  key_hash text not null unique,
  hwid_hash text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);

create index if not exists licenses_hwid_hash_idx
  on public.licenses (hwid_hash);

create index if not exists licenses_expires_at_idx
  on public.licenses (expires_at);

-- No public access. The server uses the Supabase service-role key.
alter table public.licenses enable row level security;

revoke all on table public.licenses from anon, authenticated;

-- One-time Link4M return sessions, valid for 30 minutes.
create table if not exists public.link_sessions (
  id uuid primary key default gen_random_uuid(),
  token_hash text not null unique,
  hwid_hash text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create index if not exists link_sessions_expires_at_idx on public.link_sessions (expires_at);
alter table public.link_sessions enable row level security;
revoke all on table public.link_sessions from anon, authenticated;
