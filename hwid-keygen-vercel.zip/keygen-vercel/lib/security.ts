import { createHash, randomBytes } from "node:crypto";

export function normalizeHwid(value: unknown): string | null {
  if (typeof value !== "string") return null;

  const normalized = value.trim().toLowerCase();
  if (normalized.length < 8 || normalized.length > 256) return null;
  // Reject control characters while allowing common UUID / serial formats.
  if (/[\u0000-\u001f\u007f]/.test(normalized)) return null;

  return normalized;
}

export function sha256(value: string): string {
  return createHash("sha256").update(value, "utf8").digest("hex");
}

export function createLicenseKey(): string {
  // 192 bits of cryptographic randomness; the raw key is only returned once.
  return `KEY-${randomBytes(24).toString("hex").toUpperCase()}`;
}
