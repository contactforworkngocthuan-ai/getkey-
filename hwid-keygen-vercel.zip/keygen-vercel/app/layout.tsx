import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "HWID Key System",
  description: "Tạo license key có thời hạn 24 giờ và khóa theo HWID.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="vi">
      <body>{children}</body>
    </html>
  );
}
