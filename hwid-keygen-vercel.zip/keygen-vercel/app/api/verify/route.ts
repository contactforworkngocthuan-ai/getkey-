import { NextResponse } from "next/server";
import { normalizeHwid, sha256 } from "@/lib/security";
import { getSupabaseAdmin } from "@/lib/supabase-admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: unknown;

  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Body phải là JSON hợp lệ." }, { status: 400 });
  }

  const payload = body && typeof body === "object" ? (body as Record<string, unknown>) : {};
  const key = typeof payload.key === "string" ? payload.key.trim() : "";
  const hwid = normalizeHwid(payload.hwid);

  if (!key || key.length > 128 || !hwid) {
    return NextResponse.json(
      { valid: false, error: "Thiếu key hoặc HWID không hợp lệ." },
      { status: 400 },
    );
  }

  try {
    const supabase = getSupabaseAdmin();
    const { data, error } = await supabase
      .from("licenses")
      .select("hwid_hash, expires_at")
      .eq("key_hash", sha256(key))
      .maybeSingle();

    if (error) {
      console.error("Could not verify license:", error.message);
      return NextResponse.json({ error: "Lỗi khi kiểm tra key." }, { status: 500 });
    }

    if (!data) {
      return NextResponse.json({ valid: false, reason: "KEY_NOT_FOUND" }, { status: 200 });
    }

    if (data.hwid_hash !== sha256(hwid)) {
      return NextResponse.json({ valid: false, reason: "HWID_MISMATCH" }, { status: 200 });
    }

    const expiresAt = new Date(data.expires_at);
    if (Number.isNaN(expiresAt.getTime()) || expiresAt.getTime() <= Date.now()) {
      return NextResponse.json({ valid: false, reason: "KEY_EXPIRED" }, { status: 200 });
    }

    return NextResponse.json({ valid: true, expiresAt: expiresAt.toISOString() });
  } catch (error) {
    console.error("verify configuration error:", error);
    return NextResponse.json(
      { error: "Server chưa được cấu hình Supabase. Kiểm tra Environment Variables." },
      { status: 503 },
    );
  }
}
