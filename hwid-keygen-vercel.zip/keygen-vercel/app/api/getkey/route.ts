import { NextResponse } from "next/server";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
// Direct key creation is disabled; users must complete the Link4M redirect flow.
export async function POST() {
  return NextResponse.json({ error: "Hãy lấy key qua Link4M trên trang chủ." }, { status: 403 });
}
