import { NextResponse } from "next/server";
import { normalizeHwid, sha256 } from "@/lib/security";
import { getSupabaseAdmin } from "@/lib/supabase-admin";
import { randomBytes } from "node:crypto";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  let body: unknown;
  try { body = await request.json(); } catch {
    return NextResponse.json({ error: "Body phải là JSON hợp lệ." }, { status: 400 });
  }
  const hwid = normalizeHwid(body && typeof body === "object" && "hwid" in body ? (body as { hwid?: unknown }).hwid : null);
  if (!hwid) return NextResponse.json({ error: "HWID không hợp lệ (8–256 ký tự)." }, { status: 400 });

  const apiKey = process.env.LINK4M_API_KEY;
  if (!apiKey) return NextResponse.json({ error: "Server thiếu LINK4M_API_KEY." }, { status: 503 });
  const token = randomBytes(24).toString("hex");
  const callback = new URL(`/claim?token=${token}`, request.url).toString();
  try {
    const db = getSupabaseAdmin();
    const { error: insertError } = await db.from("link_sessions").insert({ token_hash: sha256(token), hwid_hash: sha256(hwid), expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString() });
    if (insertError) throw insertError;
    const apiUrl = `https://link4m.co/api-shorten/v2?api=${encodeURIComponent(apiKey)}&url=${encodeURIComponent(callback)}`;
    const response = await fetch(apiUrl, { cache: "no-store" });
    const data = await response.json() as { status?: string; shortenedUrl?: string; message?: string };
    if (!response.ok || data.status !== "success" || !data.shortenedUrl) {
      await db.from("link_sessions").delete().eq("token_hash", sha256(token));
      return NextResponse.json({ error: data.message || "Link4M không tạo được link. Kiểm tra API key." }, { status: 502 });
    }
    return NextResponse.json({ redirectUrl: data.shortenedUrl });
  } catch (err) {
    console.error("Link4M start error", err);
    return NextResponse.json({ error: "Không thể tạo link xác minh. Kiểm tra cấu hình Supabase/Link4M." }, { status: 500 });
  }
}
