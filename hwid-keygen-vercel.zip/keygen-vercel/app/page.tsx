"use client";

import { useState } from "react";

type StartLinkResponse = { redirectUrl?: string; error?: string };

export default function Home() {
  const [hwid, setHwid] = useState("");
  const [key, setKey] = useState("");
  const [expiresAt, setExpiresAt] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  async function getKey() {
    setError("");
    setKey("");
    setExpiresAt("");
    setCopied(false);

    if (hwid.trim().length < 8) {
      setError("Vui lòng nhập HWID hợp lệ (ít nhất 8 ký tự).");
      return;
    }

    setLoading(true);
    try {
      const response = await fetch("/api/start-link", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ hwid }),
      });
      const result = (await response.json()) as StartLinkResponse;
      if (!response.ok || !result.redirectUrl) {
        throw new Error(result.error || "Không thể tạo link Link4M. Vui lòng thử lại.");
      }
      window.location.assign(result.redirectUrl);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Có lỗi xảy ra.");
    } finally {
      setLoading(false);
    }
  }

  async function copyKey() {
    if (!key) return;
    try {
      await navigator.clipboard.writeText(key);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setError("Không thể tự động copy. Hãy chọn và sao chép key thủ công.");
    }
  }

  const formattedExpiry = expiresAt
    ? new Intl.DateTimeFormat("vi-VN", {
        dateStyle: "medium",
        timeStyle: "medium",
        timeZone: "Asia/Ho_Chi_Minh",
      }).format(new Date(expiresAt))
    : "";

  return (
    <main className="shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />

      <header className="topbar">
        <a className="brand" href="#home" aria-label="HWID Key System">
          <span className="brand-mark">K</span>
          <span>KEY<span className="brand-muted">SYSTEM</span></span>
        </a>
        <span className="status"><i /> SYSTEM ONLINE</span>
      </header>

      <section className="hero" id="home">
        <div className="eyebrow"><span /> LICENSE GENERATOR <span /></div>
        <h1>GET YOUR <span>KEY.</span></h1>
        <p className="subtitle">Tạo license key riêng cho thiết bị của bạn.</p>

        <section className="panel" aria-label="Tạo key">
          <div className="panel-head">
            <div>
              <p className="panel-kicker">NEW LICENSE</p>
              <h2>Tạo key 24 giờ</h2>
            </div>
            <div className="time-badge"><span>◷</span> 24 HOURS</div>
          </div>

          <label className="field-label" htmlFor="hwid">HWID CỦA THIẾT BỊ</label>
          <div className="input-wrap">
            <span className="input-icon">⌘</span>
            <input
              id="hwid"
              value={hwid}
              onChange={(event) => setHwid(event.target.value)}
              placeholder="Nhập HWID của bạn..."
              autoComplete="off"
              spellCheck={false}
              maxLength={256}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !loading) void getKey();
              }}
            />
            <span className="input-count">{hwid.length}/256</span>
          </div>
          <p className="hint">Sau khi hoàn thành Link4M, bạn sẽ được chuyển về đây để nhận key 24 giờ gắn với HWID.</p>

          <button className="generate-button" onClick={() => void getKey()} disabled={loading}>
            {loading ? <span className="spinner" /> : <span>✳</span>}
            {loading ? "ĐANG TẠO KEY..." : "CONTINUE VIA LINK4M"}
            {!loading && <span className="button-arrow">↗</span>}
          </button>

          {error && <div className="message error-message" role="alert">{error}</div>}

          {key && (
            <div className="result" aria-live="polite">
              <div className="result-topline">
                <span className="result-label">YOUR LICENSE KEY</span>
                <span className="valid-tag"><i /> CREATED</span>
              </div>
              <div className="key-box">
                <code>{key}</code>
                <button className="copy-button" onClick={() => void copyKey()} aria-label="Copy key">
                  {copied ? "COPIED ✓" : "COPY ↗"}
                </button>
              </div>
              <div className="expiry-row">
                <span>HẾT HẠN</span>
                <strong>{formattedExpiry}</strong>
              </div>
              <p className="one-time-note">Hãy lưu key ngay. Vì lý do bảo mật, server chỉ hiển thị key đầy đủ tại thời điểm tạo.</p>
            </div>
          )}
        </section>

        <div className="feature-row">
          <div className="feature"><span>◈</span><div><strong>HWID LOCK</strong><small>Khóa theo thiết bị</small></div></div>
          <div className="feature"><span>◷</span><div><strong>24H VALID</strong><small>Tự hết hạn sau 24 giờ</small></div></div>
          <div className="feature"><span>⌁</span><div><strong>SECURE KEY</strong><small>Key ngẫu nhiên an toàn</small></div></div>
        </div>
      </section>

      <footer>
        <span>HWID KEY SYSTEM</span>
        <span>LICENSES EXPIRE AUTOMATICALLY</span>
      </footer>
    </main>
  );
}
