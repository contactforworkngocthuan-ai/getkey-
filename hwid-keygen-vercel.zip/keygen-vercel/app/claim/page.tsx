import { createLicenseKey, sha256 } from "@/lib/security";
import { getSupabaseAdmin } from "@/lib/supabase-admin";
import ClaimResult from "./ClaimResult";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function html(message?: string, key?: string, expiry?: string) {
  return (
    <main style={{ minHeight: "100vh", background: "#080b12", color: "#eef2ff", display: "grid", placeItems: "center", fontFamily: "Arial,sans-serif", padding: 24 }}>
      <section style={{ maxWidth: 520, width: "100%", background: "#121827", border: "1px solid #293348", borderRadius: 18, padding: 28 }}>
        <h1>{message ? "Link không hợp lệ" : "KEY CỦA BẠN ĐÃ SẴN SÀNG"}</h1>
        {message ? <p>{message}</p> : <ClaimResult keyValue={key!} expiry={expiry!} />}
      </section>
    </main>
  );
}

export default async function ClaimPage({ searchParams }: { searchParams: Promise<{ token?: string }> }) {
  const { token } = await searchParams;
  if (!token || !/^[a-f0-9]{48}$/.test(token)) return html("Thiếu hoặc sai token.");
  try {
    const db = getSupabaseAdmin();
    const tokenHash = sha256(token);
    const { data: session, error } = await db.from("link_sessions").select("hwid_hash, expires_at").eq("token_hash", tokenHash).maybeSingle();
    if (error || !session || new Date(session.expires_at).getTime() <= Date.now()) {
      if (session) await db.from("link_sessions").delete().eq("token_hash", tokenHash);
      return html("Phiên GET KEY đã hết hạn hoặc đã được sử dụng. Hãy quay lại và bắt đầu lại.");
    }
    const key = createLicenseKey();
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
    const { error: saveError } = await db.from("licenses").insert({ key_hash: sha256(key), hwid_hash: session.hwid_hash, expires_at: expiresAt });
    if (saveError) throw saveError;
    await db.from("link_sessions").delete().eq("token_hash", tokenHash);
    return html(undefined, key, expiresAt);
  } catch (e) {
    console.error("Claim page error", e);
    return html("Lỗi server. Hãy thử lại hoặc liên hệ quản trị viên.");
  }
}
