"use client";
export default function ClaimResult({ keyValue, expiry }: { keyValue: string; expiry: string }) {
  return <><p>Key HWID-lock · Có hiệu lực 24 giờ</p><div style={{ padding: 16, background: "#080b12", borderRadius: 10, wordBreak: "break-all", fontSize: 20 }}>{keyValue}</div><button style={{ padding: "12px 18px", marginTop: 14 }} onClick={() => void navigator.clipboard.writeText(keyValue)}>Copy key</button><p>Hết hạn: {new Date(expiry).toLocaleString("vi-VN", { timeZone: "Asia/Ho_Chi_Minh" })}</p><a style={{ color: "#91a9ff" }} href="/">Quay lại trang chủ</a></>;
}
