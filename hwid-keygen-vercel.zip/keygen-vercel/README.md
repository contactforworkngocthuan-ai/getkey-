# HWID Key System — Vercel + Supabase

Web tạo license key có thời hạn 24 giờ và ràng buộc với HWID. Project dùng Next.js App Router, API chạy phía server trên Vercel và Supabase Postgres để lưu dữ liệu bền vững.

## Chức năng

- Nhập HWID và bấm **GET KEY NOW** để tạo một key mới.
- Mỗi lần gọi `POST /api/getkey` sẽ tạo một key ngẫu nhiên mới, hạn dùng đúng 24 giờ tính từ thời điểm server tạo.
- Key được liên kết với HWID đã nhập; key không hợp lệ nếu dùng với HWID khác.
- `POST /api/verify` kiểm tra key, HWID và thời gian hết hạn.
- Database chỉ lưu SHA-256 hash của key và HWID, không lưu key gốc.

> **Giới hạn của trình duyệt:** Website không thể đọc HWID phần cứng thật (serial ổ cứng/mainboard/CPU) một cách đáng tin cậy. HWID cần được ứng dụng desktop/game/client của bạn cung cấp, hoặc người dùng tự nhập. Fingerprint trình duyệt không tương đương HWID phần cứng.

## 1. Tạo database Supabase

1. Tạo project tại https://supabase.com/.
2. Mở **SQL Editor** và chạy toàn bộ nội dung file `supabase/schema.sql`.
3. Vào **Project Settings → API** (hoặc API Keys) và lấy Project URL cùng `service_role` / secret key.

## 2. Chạy ở máy local

Cần Node.js 20.9 trở lên.

```bash
npm install
cp .env.example .env.local
```

Mở `.env.local` và điền:

```env
SUPABASE_URL=https://YOUR_PROJECT.supabase.co
SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVICE_ROLE_KEY
```

Sau đó chạy:

```bash
npm run dev
```

Mở http://localhost:3000.

## 3. Deploy lên Vercel

1. Đẩy toàn bộ project lên GitHub.
2. Vào https://vercel.com/new, import repository.
3. Trong **Project Settings → Environment Variables**, thêm hai biến:
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
4. Deploy. Sau khi deploy, website sẽ có domain dạng `https://ten-project.vercel.app`.

Không đặt tiền tố `NEXT_PUBLIC_` cho `SUPABASE_SERVICE_ROLE_KEY`. Không gửi hoặc commit key này lên GitHub. Sau khi thay đổi Environment Variables, hãy redeploy project.

## API

### Tạo key — `POST /api/getkey`

Request:

```json
{
  "hwid": "DEVICE-HWID-0123456789"
}
```

Response `201`:

```json
{
  "key": "KEY-...",
  "expiresAt": "2026-11-19T15:00:00.000Z",
  "expiresInSeconds": 86400,
  "hwidBound": true
}
```

Key gốc chỉ được trả về một lần lúc tạo. Hãy lưu key ở phía client ngay khi nhận được.

### Kiểm tra key — `POST /api/verify`

Request:

```json
{
  "key": "KEY-...",
  "hwid": "DEVICE-HWID-0123456789"
}
```

Key hợp lệ:

```json
{
  "valid": true,
  "expiresAt": "2026-11-19T15:00:00.000Z"
}
```

Key không tồn tại, sai HWID hoặc hết hạn trả `valid: false` cùng `reason` tương ứng (`KEY_NOT_FOUND`, `HWID_MISMATCH`, `KEY_EXPIRED`).

Ví dụ gọi bằng `curl`:

```bash
curl -X POST https://YOUR-APP.vercel.app/api/getkey \
  -H 'Content-Type: application/json' \
  -d '{"hwid":"DEVICE-HWID-0123456789"}'
```

## Lưu ý trước khi public

API hiện mở để client có thể gọi trực tiếp. Khi public rộng rãi, nên bổ sung CAPTCHA hoặc cơ chế xác thực/rate limit (ví dụ giới hạn yêu cầu theo IP/HWID) để tránh bị spam tạo key. Không thể dùng bộ nhớ RAM của Vercel Function làm nơi lưu quota lâu dài; cần lưu quota ở database hoặc dịch vụ rate-limit dùng chung.
